""".

AS91896 2.7 Advanced Programing

Edee's Gallery

Sophie Evans

"""


from flask import Flask, render_template
import sqlite3
app = Flask(__name__, template_folder="templates")

@app.route('/')
def root():
    conn = sqlite3.connect('GALLERY.db')
    cur = conn.cursor()
    cur.execute('SELECT categoryID , category , category_image FROM tbl_category ;')

    root = cur.fetchall()
    print(root)
    conn.close()
    return render_template('home.html', page_title='HOME', root=root)

# Error page. Loaded when requested page cannot be found
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html")

@app.route('/about')
def about():
    return render_template('about.html', page_title='ABOUT')


@app.route('/all_artwork')
def all_artwork():
    conn = sqlite3.connect('GALLERY.db')
    cur = conn.cursor()
    cur.execute('SELECT id, image_name, image, orientation FROM tbl_art;')

    all_work = cur.fetchall()
    print(all_work)
    conn.close()
    return render_template('allartwork.html', page_title='ALL ARTWORK', all_work=all_work)

@app.route('/art/<int:id>')
def art(id):
    conn = sqlite3.connect('GALLERY.db')
    cur = conn.cursor()
    cur.execute('SELECT id, image_name, description, image FROM tbl_art WHERE id=?;', (id,))

    art = cur.fetchall()
    print(art)
    conn.close()
    return render_template('art.html', page_title='ART', art=art)

@app.route('/collections_art/<int:id>')
def collections_art(id):
    conn = sqlite3.connect('GALLERY.db')
    cur = conn.cursor()
    cur.execute('SELECT id, image_name, description, image FROM tbl_art WHERE id=?;', (id,))

    collections_art = cur.fetchall()
    print(collections_art)
    conn.close()
    return render_template('collections_art.html', page_title='Artwork', collections_art=collections_art)

@app.route('/collections')
def collections():
    conn = sqlite3.connect('GALLERY.db')
    cur = conn.cursor()
    cur.execute('SELECT categoryID, category, category_image FROM tbl_category ;')
    collections = cur.fetchall()
    print(collections)
    conn.close()
    return render_template('collections.html', page_title='COLLECTIONS',collections=collections)


@app.route('/collections/<int:categoryID>')
def collection(categoryID):
    conn = sqlite3.connect('GALLERY.db')
    cur = conn.cursor()

    cur.execute('SELECT * FROM tbl_art WHERE categoryID=?;', (categoryID,))
    pictures = cur.fetchall()

    cur.execute('SELECT * FROM tbl_category WHERE categoryID=?;', (categoryID,))
    category = cur.fetchall()

    print(category)
    print(pictures)

    conn.close()
    return render_template('seperate_collections.html', page_title='yes',category=category,pictures=pictures)

@app.route('/commissions')
def commissions():
    return render_template('commissions.html', page_title='Commissions')

    
if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)